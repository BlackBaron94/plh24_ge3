package packageMain;

import javax.swing.SwingUtilities;
import packageGUI.MainFrame;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }
}
